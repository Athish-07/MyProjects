package com.chatapp.client;

import com.chatapp.crypto.CryptoUtils;
import com.chatapp.model.Message;

import javax.crypto.SecretKey;

public class ChatClient {
    private static ClientConnection connection;
    private static SecretKey aesKey;

    public static void startConnection(String username) {
        try {
            // Derive AES key from the username (or any shared secret)
            aesKey = CryptoUtils.getKeyFromPassword(username);

            connection = new ClientConnection("localhost", 5000, (msg) -> {
                try {
                    // Decrypt incoming message using the derived key
                    String decrypted = CryptoUtils.decryptAES(msg.getEncryptedText(), aesKey);

                    // Display the decrypted message in UI
                    ChatUI.displayMessage(msg.getSender(), decrypted);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void sendMessage(String username, String plainText) {
        try {
            // Encrypt message with the same derived key
            String encrypted = CryptoUtils.encryptAES(plainText, aesKey);

            Message msg = new Message(username, encrypted);

            connection.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
