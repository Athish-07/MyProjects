package com.chatapp.client;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ChatUI extends Application {
    public static TextArea chatArea = new TextArea();
    private static String username;

    @Override
    public void start(Stage stage) {
        // Prompt user for a name when the app starts
        TextInputDialog dialog = new TextInputDialog("User" + (int)(Math.random() * 1000));
        dialog.setTitle("Enter Username");
        dialog.setHeaderText("Please enter your name:");
        username = dialog.showAndWait().orElse("Anonymous");

        chatArea.setEditable(false);
        TextField inputField = new TextField();
        Button sendButton = new Button("Send");

        sendButton.setOnAction(e -> {
            String text = inputField.getText().trim();
            if (!text.isEmpty()) {
                ChatClient.sendMessage(username, text);  // send with username
                inputField.clear();
            }
        });

        VBox layout = new VBox(10, chatArea, inputField, sendButton);
        stage.setScene(new Scene(layout, 400, 300));
        stage.setTitle("Encrypted Chat Client - " + username);
        stage.show();

        ChatClient.startConnection(username);  // start connection with username
    }

    // This method is called by ChatClient when a new message is received
    public static void displayMessage(String sender, String message) {
        Platform.runLater(() -> {
            chatArea.appendText(sender + ": " + message + "\n");
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}
