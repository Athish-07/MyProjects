package com.chatapp.client;

import com.chatapp.model.Message;
import java.io.*;
import java.net.Socket;
import java.util.function.Consumer;

public class ClientConnection {
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private Thread listenThread;

    public ClientConnection(String host, int port, Consumer<Message> messageHandler) throws IOException {
        socket = new Socket(host, port);
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());

        listenThread = new Thread(() -> {
            try {
                while (!Thread.currentThread().isInterrupted()) {
                    Message msg = (Message) in.readObject();
                    messageHandler.accept(msg);
                }
            } catch (Exception e) {
                System.out.println("Disconnected from server.");
            }
        });
        listenThread.setDaemon(true);
        listenThread.start();
    }

    public void sendMessage(Message message) {
        try {
            out.writeObject(message);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void close() {
        try {
            if (listenThread != null && listenThread.isAlive()) {
                listenThread.interrupt();
            }
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
