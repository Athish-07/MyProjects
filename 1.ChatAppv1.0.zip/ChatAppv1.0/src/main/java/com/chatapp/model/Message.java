package com.chatapp.model;

import java.io.Serializable;

public class Message implements Serializable {
    private String sender;
    private String encryptedText;

    public Message(String sender, String encryptedText) {
        this.sender = sender;
        this.encryptedText = encryptedText;
    }

    public String getSender() {
        return sender;
    }

    public String getEncryptedText() {
        return encryptedText;
    }
}
