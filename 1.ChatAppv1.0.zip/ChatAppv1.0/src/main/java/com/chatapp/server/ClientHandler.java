package com.chatapp.server;

import com.chatapp.crypto.CryptoUtils;
import com.chatapp.model.Message;

import javax.crypto.SecretKey;
import java.io.*;
import java.net.Socket;

public class ClientHandler implements Runnable {
    private Socket socket;
    private ObjectOutputStream out;
    private ObjectInputStream in;

    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        out = new ObjectOutputStream(socket.getOutputStream());
        in = new ObjectInputStream(socket.getInputStream());
    }

    public void send(Message message) {
        try {
            out.writeObject(message);
            out.flush();
        } catch (IOException e) {
            System.out.println("Error sending message to client.");
        }
    }

    @Override
    public void run() {
        try {
            while (true) {
                Message msg = (Message) in.readObject();
                String sender = msg.getSender();

                // Decrypt message using sender's key
                SecretKey senderKey = CryptoUtils.getKeyFromPassword(sender);
                String decryptedText = CryptoUtils.decryptAES(msg.getEncryptedText(), senderKey);

                // Re-encrypt message for each client using their own key
                for (ClientHandler client : ChatServer.clients) {
                    if (client != this) {
                        // Encrypt using recipient's key (assuming usernames are same for now)
                        SecretKey recipientKey = CryptoUtils.getKeyFromPassword(sender); // or use recipient username if known
                        String reEncryptedText = CryptoUtils.encryptAES(decryptedText, recipientKey);

                        Message newMsg = new Message(sender, reEncryptedText);
                        client.send(newMsg);
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Client disconnected.");
        } finally {
            try {
                socket.close();
            } catch (IOException ignored) {
            }

            ChatServer.clients.remove(this);
        }
    }
}
