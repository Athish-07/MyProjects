package emailapp;

import java.util.Scanner;

public class email {
    private final String firstName;
    private final String lastName;
    private String password;
    private final String department;
    private String email;
    private int mailboxCapacity = 500;
    private String alternateEmail;
    private final int defaultPasswordLength = 7;
    private final int defaultPasswordLength2 = 3;
    private final String CompanyName = "tcs";

    // Constructor
    public email() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your FirstName : ");
        this.firstName = sc.nextLine().trim();
        System.out.print("Enter your LastName : ");
        this.lastName = sc.nextLine().trim();

        this.department = setDepartment().trim();
        System.out.print("Processing");
        for (int i = 0; i < 6; i++) {
            Thread.sleep(500);
            System.out.print(".");
        }
        System.out.println();
        System.out.println("Congrats!! Your emailID has been created Successfully\n");
        for (int i = 0; i < 3; i++) {
            Thread.sleep(500);
        }

        this.password = randomPassword(defaultPasswordLength, defaultPasswordLength2);

        // Generate email
        email = firstName.toLowerCase() + lastName.toLowerCase() + "." + department.toLowerCase() + "@" + CompanyName + ".com";
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Your email is :" + email);

        System.out.println("Your Password is :" + this.password.substring(0,1).toUpperCase()+this.password.substring(1));
       System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");

        changePassword();
        changeEmail();
    }

    // Ask Dept
    private String setDepartment() {
        System.out.println("CHOOSE YOUR DEPARTMENT :\n1.Sales\n2.Development\n3.Accounting\n0.None");
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter your Department code :");
        int deptChoice = sc.nextInt();
        sc.nextLine(); // consume newline
        if (deptChoice == 1) return "Sales";
        else if (deptChoice == 2) return "Development";
        else if (deptChoice == 3) return "Accounting";
        else return "";
    }

    // Generate Password
    public void setPassword(String changepassword) {
        this.password = changepassword;
    }

    public void setEmail(String email){
        this.email=email;
    }

    private String randomPassword(int length, int length2) {
        String passwordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        char[] password = new char[length];
        for (int i = 0; i < length; i++) {
            int rand = (int) (Math.random() * passwordSet.length());
            password[i] = passwordSet.charAt(rand);
        }

        String passwordnum = "0123456789";
        char[] password2 = new char[length2];
        for (int i = 0; i < length2; i++) {
            int rand2 = (int) (Math.random() * 3);
            password2[i] = passwordnum.charAt(rand2);
        }

        return new String(password)+ "@" + new String(password2);
    }

    // Change password
    public void changePassword() throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Do you want to Change Your Password ?? Yes/No");
        String ans = sc.nextLine();
        if (ans.equalsIgnoreCase("Yes")) {
            System.out.println("Create your Alternate Password");
            String changepass = sc.nextLine();
            System.out.print("Changing Your Password");
            for (int i = 0; i < 5; i++) {
                Thread.sleep(500);
                System.out.print(".");
            }
            System.out.println();
            setPassword(changepass);
            System.out.println("Your Password have been changed successfully");
            System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }
        else {
            System.out.println("Password has not been changed");
            System.out.println();
        }
    }


    public void changeEmail() throws InterruptedException {
        System.out.println("Do you Want to Change your Default Mail? Yes/No");
        Scanner sc=new Scanner(System.in);
        String ans=sc.nextLine().trim();
        if(ans.equalsIgnoreCase("Yes")){
            System.out.println("Enter Your Alternate Email: ");
            String altemail= sc.nextLine().trim();

            System.out.print("Changing Your Email");
            for (int i = 0; i < 5; i++) {
                Thread.sleep(500);
                System.out.print(".");
            }
            System.out.println();
            setEmail(altemail);
            System.out.println("Email have been Changed Successfully");

        }
        else{
            System.out.println("Email have not been changed");
        }


    }

    // Set mailbox capacity
    public void setMailboxCapacity(int capacity) {
        this.mailboxCapacity = capacity;
    }

    // Set alternate email
    public void setAlternateEmail(String alternateEmail) {
        this.alternateEmail = alternateEmail;
    }

    public int getMailboxCapacity() {
        return mailboxCapacity;
    }

    public String getAlternateEmail() {
        return alternateEmail;
    }

    public String showInfo() {
        return "+++++++++++++++++++++++++++++++++++++++++++++++++++++" +
                "\nDISPLAY NAME :" + firstName + " " + lastName +
                "\nCOMPANY EMAIL :" + email +
                "\nMAILBOX CAPACITY :" + mailboxCapacity + "mb" +
                "\nPASSWORD IS :" + password;
    }
}
