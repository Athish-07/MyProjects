package emailapp;

public class emailApp {
    public static void main(String[] args) throws InterruptedException {
//email em1 = new email("Haris", "Athish");
        email em1=new email();
        System.out.println(em1.showInfo());
        System.out.println("+++++++++++++++++++++++++++++++++++++++++++++++++++++");
    }


}