package com.example.casino;

import com.example.casino.SlotService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;


@Controller
@SessionAttributes("balance")
public class CasinoController {

    private final SlotService slotService;

    public CasinoController(SlotService slotService) {
        this.slotService = slotService;
    }

    @ModelAttribute("balance")
    public Integer balance() {
        return 100; // initial balance
    }

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message", "Welcome to Casino World 🎰");
        return "index";
    }

    @PostMapping("/spin")
    public String playGame(@RequestParam int bet, @ModelAttribute("balance") Integer balance, Model model) {
        if (bet <= 0 || bet > balance) {
            model.addAttribute("error", "Invalid bet amount!");
            return "index";
        }

        String[] result = slotService.spin();
        int winnings = slotService.calculateWinnings(result, bet);
        int newBalance = balance - bet + winnings;

        model.addAttribute("result", result);
        model.addAttribute("winnings", winnings);
        model.addAttribute("balance", newBalance);

        return "result";
    }
}
