package com.example.casino;

import org.springframework.stereotype.Service;

import java.util.Random;

@Service
public class SlotService {
	private final String[] symbols = {"🍇", "🍎", "🍈", "🍍", "🍌"};

	public String[] spin() {
		Random random = new Random();
		return new String[]{
				symbols[random.nextInt(symbols.length)],
				symbols[random.nextInt(symbols.length)],
				symbols[random.nextInt(symbols.length)]
		};
	}

	public int calculateWinnings(String[] spinResult, int bet) {
		if (spinResult[0].equals(spinResult[1]) && spinResult[0].equals(spinResult[2])) {
			switch (spinResult[0]) {
				case "🍇" -> { return bet * 3; }
				case "🍎" -> { return bet * 4; }
				case "🍈" -> { return bet * 5; }
				case "🍍", "🍌" -> { return bet * 6; }
			}
		}
		return 0;
	}
}
