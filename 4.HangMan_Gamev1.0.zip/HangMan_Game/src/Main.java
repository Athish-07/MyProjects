

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public  class Main {

    public static void main(String[] args) throws InterruptedException {

        String path="src/textFile.txt";
        ArrayList<String> textword=new ArrayList<>();

        try(BufferedReader reader=new BufferedReader(new FileReader(path))){
            String line;
            while((line = reader.readLine()) !=null){
                textword.add(line.trim());
            }

        }catch(IOException e){
            System.out.println("No input");
        }
        Random random=new Random();
        String word1=textword.get(random.nextInt(textword.size()));



        String word=word1;
        int wrongguess=0;
        ArrayList<Character> wordlist=new ArrayList<>();
        Scanner sc = new Scanner(System.in);

        for(int i=0;i<word.length();i++){
            wordlist.add('_');
        }
        System.out.println("");
        System.out.println("""
                ✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️
                ✖️                                 ✖️
                ✖️        JAVA HANGMAN GAME        ✖️
                ✖️                                 ✖️
                ✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️✖️
                """);

        System.out.println(" ");
        System.out.print("Game is Starting");
        for(int i=0;i<5;i++) {
            System.out.print(".");
            Thread.sleep(950);
        }
        System.out.print("\rPlease wait");
        for(int i=0;i<3;i++) {
            System.out.print(".");
            Thread.sleep(950);
        }
        Thread.sleep(1500);
        System.out.println("");
        System.out.println(" ");

        while(wrongguess<6) {
            System.out.print("Guess the Word: ");
            for (char c : wordlist) {
                System.out.print(c + " ");
            }

            System.out.println("");
            System.out.print("Enter your letter: ");
            char enterword = sc.next().toLowerCase().charAt(0);

            if (word.indexOf(enterword) >= 0) {
                System.out.print("Checking");
                for(int i=0;i<5;i++) {
                    System.out.print(".");
                    Thread.sleep(450);
                }
                System.out.print("\rCORRECT !!");
                Thread.sleep(500);
                System.out.println();
                System.out.println(" ");
                for (int i = 0; i < wordlist.size(); i++) {
                    if (word.charAt(i) == enterword) {
                        wordlist.set(i, enterword);
                    }
                }
                if(!wordlist.contains('_')){
                    if(wrongguess>=1) {
                        System.out.println(hangman(wrongguess));
                        String ab=word;
                        for(char c: wordlist){
                            System.out.print(c+" ");
                            Thread.sleep(300);
                        }
                        System.out.println("The Word is "+"'"+ab+"'");
                        break;
                    }
                    else {
                        System.out.println("Congrats !! YOU WON ");
                        String ab=word;

                        for(char c: wordlist){
                            System.out.print(c+" ");
                            Thread.sleep(300);
                        }
                        System.out.println("");
                        System.out.println("The Word is "+"'"+ab+"'");
                        break;
                    }
                }
            }
            else {
                wrongguess++;
                System.out.print("Checking");
                for(int i=0;i<5;i++) {
                    System.out.print(".");
                    Thread.sleep(450);
                }
                Thread.sleep(500);
                System.out.println(" ");
                System.out.println("\rWRONG GUESS !! ");
                System.out.println("");
                System.out.println(hangman(wrongguess));
                System.out.println(" ");

            }



        }
        sc.close();

        if(wrongguess>=6){
            System.out.println(hangman(wrongguess));
            System.out.println("Game OVER");
            System.out.println("The Word is "+word.toUpperCase());
            System.out.println();
        }


    }
    static String hangman(int wrongguess){
        return switch(wrongguess){
            case 0 -> """
                      
                      
                      """;
            case 1 -> """
                        O
                      
                      """;
            case 2 -> """
                        O
                        |
                      
                      """;
            case 3 -> """
                        O
                       /|  
                      
                      """;
            case 4 -> """
                        O
                       /|\\
                      
                      """;
            case 5 -> """
                        O
                       /|\\
                       /
                      """;
            case 6 -> """
                        O
                       /|\\
                       / \\
                      """;
            default -> "";
        };
    }
}