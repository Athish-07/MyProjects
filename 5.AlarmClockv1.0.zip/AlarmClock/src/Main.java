import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public  class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String path="src\\file_example_WAV_2MG.wav";
        DateTimeFormatter formatter =DateTimeFormatter.ofPattern("HH:mm:ss");
        LocalTime alarmTime=null;

        while (alarmTime==null) {
            try {

                System.out.print("Enter  an alarm time (HH:MM:SS) :");
                String inputtime = sc.nextLine();

                alarmTime = LocalTime.parse(inputtime, formatter);
                System.out.println("Alarm set at :" + alarmTime);
            } catch (Exception e) {
                System.out.println("Please Enter Valid Time !!");
            }
        }

        alarmClock alarm=new alarmClock(alarmTime,path,sc);
        Thread alarmthread=new Thread(alarm);
        alarmthread.start();



    }
}