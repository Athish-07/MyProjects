import javax.sound.sampled.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.time.LocalTime;
import java.util.Scanner;

public class alarmClock implements Runnable{

    private final LocalTime alarmTime;
    private final String path;
    private final Scanner sc;
    alarmClock(LocalTime alarmTime,String path,Scanner sc){
        this.alarmTime=alarmTime;
        this.path=path;
        this.sc=sc;
    }

    @Override
    public void run(){

        while (LocalTime.now().isBefore(alarmTime)) {
            try{
                Thread.sleep(1000);
                int hours=LocalTime.now().getHour();
                int min=LocalTime.now().getMinute();
                int sec=LocalTime.now().getSecond();


                System.out.print("\r"+hours+":"+min+":"+sec);
            }catch (InterruptedException e){
                System.out.println("Thread is Interrupted");
            }
        }
        System.out.println("Alarm Noise");
        playsound(path);

    }
    private void playsound(String path){
        File audofile=new File(path);
        try(AudioInputStream audioInputStream= AudioSystem.getAudioInputStream(audofile)){
            Clip clip=AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
            System.out.print("Press *enter* to stop alarm :");
            sc.nextLine();


            sc.close();
            clip.stop();
            Thread.sleep(10000);

        }catch (UnsupportedAudioFileException | IOException e){
            System.out.println("file not supported");
        } catch (LineUnavailableException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }
}
