package com.chat;

public enum MessageType {

    CHAT,
    JOIN,
    LEAVE
}
